def getName(reply):
    replyList = reply.split()
    if len(replyList) == 1:
        return reply
    elif "my name is" in reply.lower():
        return replyList[replyList.index('name')+2]
    elif "i am" in reply.lower():
        return replyList[replyList.index('am')+1]
    elif "i'm" in reply.lower():
        return replyList[replyList.index("I'm")+1]

def getLevel(reply):
    reply = reply.lower()
    if 'easy' in reply:
        return 'easy'
    elif 'medium' in reply:
        return 'medium'
    elif 'hard' in reply:
        return 'hard'
    else:
        return -1

def getDuration(reply):
    replyList = reply.split()
    if len(replyList) == 1:
        return reply
    elif "minutes" in reply.lower():
        return replyList[replyList.index('minutes')-1]
    elif "mins" in reply.lower():
        return replyList[replyList.index('mins')-1]
    else:
        return -1

def resetFlow(flow):
    for i in range(2,len(flow)):
        flow[i] = False