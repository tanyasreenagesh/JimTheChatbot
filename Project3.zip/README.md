To chat with Jim, the workout planner chatbot, run:
~~~
python chatbot.py
~~~