# Chatbot

#import re
from inputHandling import *
from outputHandling import *

# 0: intro/get name of user
# 1: ask to tell joke 
# 2: ask difficulty level
# 3: ask duration of workout
# 4: create workout
flow = [False, False, False, False, False]
name = ''
diffLevel = ''

def send():
    while True:
        if not flow[0]:
            JimSay("greetings+intro")
            reply = input("YOU: ")
            name = getName(reply)
            flow[0] = True

        elif not flow[1]:
            JimSay("ask to tell a joke", name)
            reply = input("YOU: ")
            saidJoke = tellJoke(reply)
            flow[1] = True
        
        elif not flow[2]:
            JimSay("ask for level", saidJoke)
            reply = input("YOU: ")
            diffLevel = getLevel(reply)
            if diffLevel == -1:
                JimSay("try again")
            else:
                JimSay("response for " + diffLevel, name)
                flow[2] = True
        
        elif not flow[3]:
            JimSay("ask for duration")
            reply = input("YOU: ")
            duration = getDuration(reply)
            if duration == -1:
                JimSay("try again")
            else:
                flow[3] = True
            
        elif not flow[4]:
            JimSay("reveal plan", name)
            print("JIM:", createWorkout(diffLevel, duration))

            # Check if workout needs to be changed
            JimSay("change workout")
            reply = input("YOU: ")
            while "no" not in reply.lower():
                print("JIM:", createWorkout(diffLevel, duration))
                JimSay("change workout")
                reply = input("YOU: ")
                
            print("JIM: Awesome, happy to help, " + name + "!")
            flow[4] = True
                

        else:
            break


send()